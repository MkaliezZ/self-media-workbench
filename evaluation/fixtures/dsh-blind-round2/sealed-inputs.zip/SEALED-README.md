# DSH Round-2 sealed blind-test inputs

This directory is the immutable input snapshot for task `DSH-R2-20261025-B`.

- `sealed-task.md` — original task card and observable acceptance criteria, written before reading product docs.
- `sealed/` — original article image, transparent-hole foreground, real SAPI TTS WAVs, text/JSON inputs.
- `sealed-manifest.json` — SHA-256 of every sealed input at seal time.
- `SEALED-MANIFEST.sha256` — SHA-256 of the manifest itself.
- `checkout-provenance.json` — clone URL, commit, clone time, and the initial top-level-only observation.

Verify later with:

```powershell
python verify_seal.py
```

The product was not implemented or patched by this test. Test materials are synthetic and must not be presented as real account performance or a real publication.
