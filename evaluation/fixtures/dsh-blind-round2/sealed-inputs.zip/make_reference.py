# -*- coding: utf-8 -*-
"""Create a human-readable composition reference and basic asset invariants.

Not a product output. It demonstrates how the sealed article can sit behind the
sealed foreground's true alpha hole for later comparison.
"""
from pathlib import Path
from PIL import Image
import json

SEALED = Path(__file__).resolve().parent / "sealed"

article = Image.open(SEALED / "article-source.png").convert("RGBA")
fg = Image.open(SEALED / "foreground-hole.png").convert("RGBA")
canvas = Image.new("RGBA", (1080, 1920), (248, 246, 240, 255))

scaled = article.resize((780, 1040), Image.Resampling.LANCZOS)
canvas.alpha_composite(scaled, (150, 440))
canvas.alpha_composite(fg, (0, 0))
canvas.convert("RGB").save(SEALED / "reference-composite.png", optimize=True)

checks = {
    "article": {
        "size": list(article.size),
        "orange_panel_pixel": list(article.getpixel((800, 620))),
        "cream_background_pixel": list(article.getpixel((40, 900))),
        "expected_orange_panel_rgb": [210, 74, 44],
        "expected_cream_background_rgb": [243, 235, 221],
    },
    "foreground": {
        "size": list(fg.size),
        "hole_center": list(fg.getpixel((540, 960))),
        "frame_opaque_pixel": list(fg.getpixel((105, 900))),
        "transparent_pixels": sum(1 for p in fg.getdata() if p[3] == 0),
        "semi_transparent_pixels": sum(1 for p in fg.getdata() if 0 < p[3] < 255),
    },
    "reference_composite": {
        "size": [1080, 1920],
        "hole_center_pixel": list(Image.open(SEALED / "reference-composite.png").getpixel((540, 960))),
    },
}
(SEALED / "asset-checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(checks, ensure_ascii=False, indent=2))
