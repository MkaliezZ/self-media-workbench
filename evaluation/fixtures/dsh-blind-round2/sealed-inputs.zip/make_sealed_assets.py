# -*- coding: utf-8 -*-
"""Generate the sealed, original Round-2 blind-test materials.

Run before reading the product documentation/schema/implementation.
Outputs are deterministic images/JSON/text; TTS WAV is generated separately
with Windows SAPI and then hashed into the seal.
"""
from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
SEALED = ROOT / "sealed"
SEALED.mkdir(exist_ok=True)

FONT_CN = r"C:\Windows\Fonts\msyh.ttc"
FONT_BOLD = r"C:\Windows\Fonts\msyhbd.ttc"

CREAM = (243, 235, 221, 255)
INK = (45, 44, 39, 255)
MUTED = (94, 91, 82, 255)
ORANGE = (210, 74, 44, 255)
TEAL = (24, 51, 58, 255)
GOLD = (211, 167, 93, 255)


def font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size=size)


def article_image() -> None:
    W, H = 1080, 1440
    img = Image.new("RGB", (W, H), CREAM[:3])
    d = ImageDraw.Draw(img)

    # Masthead / provenance, intentionally visible in the pixels.
    d.text((80, 52), "原文素材 · 合成示例 · 非真实报道", font=font(FONT_CN, 26), fill=MUTED)
    d.line((80, 100, 1000, 100), fill=(184, 171, 149), width=3)

    d.text((80, 130), "梅雨季衣柜", font=font(FONT_BOLD, 92), fill=INK)
    d.text((80, 235), "有潮味怎么办？", font=font(FONT_BOLD, 92), fill=INK)
    d.text((84, 360), "租房党三步防潮清单", font=font(FONT_CN, 42), fill=ORANGE)

    steps = [
        ("01", "开门吹风", "柜门打开，风扇对着吹十分钟，让空气先动起来。"),
        ("02", "只放下层", "衣柜下层放一盒干燥剂，樟脑丸别直接贴衣服。"),
        ("03", "留出一拳", "衬衫和外套分开放，中间留出一拳的距离。"),
    ]
    top = 455
    for num, head, body in steps:
        d.rounded_rectangle((80, top, 690, top + 225), radius=18, fill=(250, 245, 234), outline=(216, 203, 181), width=2)
        d.text((108, top + 24), num, font=font(FONT_BOLD, 30), fill=ORANGE)
        d.text((178, top + 18), head, font=font(FONT_BOLD, 48), fill=INK)
        # Manual wrap to keep each line short and legible.
        d.text((108, top + 95), body[:17], font=font(FONT_CN, 33), fill=INK)
        d.text((108, top + 144), body[17:], font=font(FONT_CN, 33), fill=INK)
        top += 253

    # Flat orange evidence panel: a fixed, measurable source region.
    d.rounded_rectangle((735, 470, 1010, 830), radius=14, fill=ORANGE)
    d.text((770, 508), "重点", font=font(FONT_BOLD, 56), fill=(255, 250, 240))
    d.text((770, 608), "干燥剂", font=font(FONT_BOLD, 50), fill=(255, 250, 240))
    d.text((770, 670), "只放下层", font=font(FONT_BOLD, 50), fill=(255, 250, 240))
    d.text((770, 766), "别贴衣服", font=font(FONT_CN, 28), fill=(255, 232, 220))

    d.line((80, 1265, 1000, 1265), fill=(184, 171, 149), width=3)
    d.text((80, 1290), "阿梨的租房小课（合成账号）· 测试文章，不构成专业建议", font=font(FONT_CN, 25), fill=MUTED)
    d.text((80, 1335), "所有文本、图片与账号数据仅供本次独立盲测使用。", font=font(FONT_CN, 25), fill=MUTED)
    img.save(SEALED / "article-source.png", optimize=True)


def foreground_image() -> None:
    # 2x supersampling for a clean alpha edge.
    S = 2
    W, H = 1080 * S, 1920 * S
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    outer = (70 * S, 250 * S, 1010 * S, 1650 * S)
    d.rounded_rectangle(outer, radius=54 * S, fill=(24, 51, 58, 244))
    # Gold inner stroke (opaque frame).
    d.rounded_rectangle((96 * S, 276 * S, 984 * S, 1624 * S), radius=40 * S, outline=GOLD, width=5 * S)
    # True transparent hole: alpha is erased completely, not white-filled.
    hole = (150 * S, 360 * S, 930 * S, 1560 * S)
    d.rounded_rectangle(hole, radius=26 * S, fill=(0, 0, 0, 0))

    # Labels sit on the opaque frame.
    d.text((118 * S, 286 * S), "阿梨的租房小课", font=font(FONT_BOLD, 34 * S), fill=(246, 238, 223, 255))
    d.text((118 * S, 1590 * S), "梅雨季 · 防潮清单", font=font(FONT_CN, 30 * S), fill=(246, 238, 223, 255))
    # Corner ticks for visual layering without covering the hole.
    for x1, y1, x2, y2 in [
        (118, 1180, 118, 1260), (118, 1180, 198, 1180),
        (962, 1180, 962, 1260), (882, 1180, 962, 1180),
    ]:
        d.line((x1 * S, y1 * S, x2 * S, y2 * S), fill=GOLD, width=4 * S)

    img = img.resize((1080, 1920), Image.Resampling.LANCZOS)
    img.save(SEALED / "foreground-hole.png", optimize=True)


def metadata() -> None:
    account = {
        "synthetic": True,
        "provenance": "DSH-R2-20261025-B original synthetic test input; not real account data",
        "account_name": "阿梨的租房小课（合成）",
        "platform": "抖音（仅测试，不发布）",
        "niche": "一线城市租房生活实用技巧",
        "window_days": 30,
        "followers": 1280,
        "posts": 12,
        "metrics": {
            "avg_views": 2100,
            "completion_rate": 0.18,
            "save_rate": 0.021,
            "share_rate": 0.006,
            "comment_rate": 0.004,
            "profile_visit_rate": 0.053,
            "follow_conversion_rate": 0.008,
        },
        "peak_traffic_hour": "22:00",
        "audience": {"age_25_34_pct": 0.61, "female_pct": 0.68},
        "unknown_facts": ["完播曲线细粒度数据", "粉丝设备分布", "成交/转化数据", "真实平台热榜"],
        "instruction": "所有诊断必须明确标注这是合成数据；不得把未知事实补成真实观察。",
    }
    (SEALED / "account-profile.json").write_text(json.dumps(account, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    review = {
        "synthetic": True,
        "provenance": "DSH-R2-20261025-B original synthetic post-review input; no real publish occurred",
        "post_title": "梅雨季衣柜有潮味，先别喷香水",
        "published_at": "2026-10-24T22:10:00+08:00 (synthetic, never actually published)",
        "window": "24h (synthetic)",
        "metrics": {
            "views": 1860,
            "completion_rate": 0.214,
            "save_rate": 0.030,
            "comments": 11,
            "shares": 6,
            "new_followers": 9,
            "avg_watch_seconds": 17.2,
        },
        "traffic_sources": {"recommend": 0.82, "profile": 0.07, "search": 0.06, "other": 0.05},
        "limitations": "无真实发布、无平台后台截图、无更长时间窗口；只能做合成复盘演练。",
    }
    (SEALED / "review-data.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    script = (
        "梅雨季衣柜有潮味，先别急着喷香水。"
        "第一步，把柜门打开，用风扇对着吹十分钟，让空气先动起来。"
        "第二步，只在衣柜下层放一盒干燥剂，别把樟脑丸直接贴在衣服上。"
        "第三步，衬衫和外套分开放，中间留出一拳的距离。"
        "今晚照做，明早再闻，评论区告诉我，你家衣柜最潮的是哪一层。"
    )
    (SEALED / "voice-script.txt").write_text(script + "\n", encoding="utf-8")

    brief = {
        "task_id": "DSH-R2-20261025-B",
        "project_name": "阿梨的租房小课 · 梅雨季衣柜防潮 · DSH-R2-B",
        "second_project_name": "阿梨的租房小课 · 快递纸箱收纳 · DSH-R2-B2",
        "selected_topic": "梅雨季衣柜有潮味，先别喷香水：租房党三步防潮",
        "tone": "口语、短句、先动作后解释",
        "target_duration_seconds": [25, 38],
        "visual_requirements": {
            "article_source": "sealed/article-source.png",
            "article_size": [1080, 1440],
            "foreground_source": "sealed/foreground-hole.png",
            "foreground_size": [1080, 1920],
            "orange_panel_pixel": [800, 620],
            "orange_panel_rgb": [210, 74, 44],
            "cream_background_pixel": [40, 900],
            "cream_background_rgb": [243, 235, 221],
            "hole_center_pixel": [540, 960],
            "hole_center_alpha": 0,
            "frame_opaque_pixel": [105, 900],
            "frame_opaque_rgb": [24, 51, 57],
        },
        "unknown_facts": "不得声称真实平台热榜、真实流量或真实发布结果。",
    }
    (SEALED / "task-brief.json").write_text(json.dumps(brief, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    (SEALED / "negative-plan.md").write_text(
        """# Sealed negative-case plan

1. After a script revision has advanced the project, submit a mutation carrying the previous revision/head. Expect conflict/rejection and unchanged current revision.
2. Truncate a copy of article-source.png and a copy of voice-source.wav; request compile/transcribe. Expect a clear source failure and no fabricated successful export.
3. Request an out-of-bounds article coordinate (e.g. x=-40 or x=5000), a negative timestamp, or a nonexistent effect parameter. Expect validation failure and no head/revision change.
4. Cross-use project A's id with project B's artifact id (both directions). Expect isolation and no cross-project mutation.

For every case record exact request, response, before/after project head and revision, list of export jobs, and disk changes. A product rejection is not a failure; accepting invalid state without a later explicit reconciliation is a product defect.
""",
        encoding="utf-8",
    )


def main() -> None:
    article_image()
    foreground_image()
    metadata()
    print("generated sealed materials in", SEALED)


if __name__ == "__main__":
    main()
