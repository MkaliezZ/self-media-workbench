# Sealed negative-case plan

1. After a script revision has advanced the project, submit a mutation carrying the previous revision/head. Expect conflict/rejection and unchanged current revision.
2. Truncate a copy of article-source.png and a copy of voice-source.wav; request compile/transcribe. Expect a clear source failure and no fabricated successful export.
3. Request an out-of-bounds article coordinate (e.g. x=-40 or x=5000), a negative timestamp, or a nonexistent effect parameter. Expect validation failure and no head/revision change.
4. Cross-use project A's id with project B's artifact id (both directions). Expect isolation and no cross-project mutation.

For every case record exact request, response, before/after project head and revision, list of export jobs, and disk changes. A product rejection is not a failure; accepting invalid state without a later explicit reconciliation is a product defect.
