# -*- coding: utf-8 -*-
"""Verify every sealed input against sealed-manifest.json and its detached hash."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "sealed-manifest.json"
DETACHED = ROOT / "SEALED-MANIFEST.sha256"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    if not MANIFEST.exists():
        print("FAIL: sealed-manifest.json missing")
        return 1
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    problems: list[str] = []

    if DETACHED.exists():
        fields = DETACHED.read_text(encoding="utf-8").strip().split()
        if not fields or fields[0] != sha256(MANIFEST):
            problems.append("detached manifest hash mismatch")
    else:
        problems.append("detached manifest hash missing")

    for rel, rec in sorted(manifest.get("files", {}).items()):
        p = ROOT / rel
        if not p.is_file():
            problems.append(f"missing: {rel}")
            continue
        actual = sha256(p)
        if actual != rec["sha256"]:
            problems.append(f"changed: {rel} expected={rec['sha256'][:16]} actual={actual[:16]}")

    result = {
        "ok": not problems,
        "task_id": manifest.get("task_id"),
        "sealed_at": manifest.get("sealed_at"),
        "file_count": manifest.get("file_count"),
        "checked_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
        "problems": problems,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
