# 独立高级口播验收 capsule

自制微型气象站动画、透明巡检卡和已声明 AI 旁白；18 秒、30 fps、540 帧。先封存素材和判据，后读取产品接口编写驱动，不使用主展示片或主测试答案。`SEALED_ADVANCED_NARRATION_TASK.md` 与 `materials/manifest.json` 保留封存原字节。

给执行 Agent：使用当前 Windows/macOS 原生 Python 3.11+，将本目录完整搬至任意位置，调用 `run_acceptance.py --repo <实际工作台仓库> --out <全新证据目录>`。Agent 管理命令，不要求最终使用者记命令。入口自动复用可用依赖，缺少 Python 依赖时在新证据目录创建隔离 runtime 并安装仓库 requirements 和 psutil；不下载 ASR 模型，不调用付费服务。FFmpeg/ffprobe 由调用 Agent 按仓库 README 安装到本机或进程 PATH，缺项会明确失败；入口不改全局 PATH。Windows、Apple Silicon 和 Intel macOS 必须分别原生执行，不能把一个平台结果复制为另一个平台通过。

入口按真实 task→catalog/schema→compile→save→export，导出普通、高级、无质感、独立暗角、独立颗粒、修改、恢复七版。比较源图像像素/原文编号、3/7/11/15 秒中间姿态、正向透视、真实 alpha 洞、颗粒时变、声音 PCM、实际帧数、frozen 源哈希与模式定义。随后做 23 项非法输入拒绝/状态不变检查、真实隔离服务重启和 frozen head 再导出。每条请求、终态、MP4、比较器和失败均留下。`RESULT.json` 表示这些技术判据，不能称为人声真实性、人工听审、审美质量、运营效果、词级 ASR 对齐或主 90 秒样片验收。

PNG/视频中文字已成为封存像素，运行不需 Windows 字体；不携带任何字体文件。原始 Windows 创作生成器保留在本机总证据目录，不属于跨平台运行链；capsule直接使用哈希封存的原创素材，不要求 macOS 重生成相同音色。旁白源 WAV、原稿及生成声明随素材保留。`creation-record/pre_advanced_read_seal.json` 另含本机创作记录/预检的原始哈希，所列额外文件未全部打包。所有素材是插画/合成，不是真人实拍或真实气象读数。

`creation-record` 还保留初版比较器。首版结束帧全帧 RMSE<0.5 将 H.264 约0.61残差误报；修订采用原卡片区域 MAE 与高差异像素比例核对残影，原报告在 Windows 总证据目录保留。封存任务、素材和关键帧误差标准没有修改。首次产品失败是零 PCM 音轨被当作口播并真实导出；修订后的新静音拒绝已进入此 capsule。真实旧计划的409预检另见原 Windows 历史报告，此 capsule 不伪造历史计划。

每个 `--out` 必须不存在，入口不会覆盖任何旧证据。它只终止已核验仓库路径/命令行、属于该次隔离 state 的自有服务。打包不包含产品 clone、导出缓存、模型、字体、凭据、参考账号或外部原片。当前只声明 Windows 实际成绩；Mac 待用户验收后另行安排，未推送 GitHub、未触发 CI。
