"""Standalone native workbench CLI/API client; no product test imports."""
from pathlib import Path
import copy,json,os,subprocess,sys,time,urllib.request,urllib.error,uuid
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
class Client:
    def __init__(self,repo,out):
        self.repo,self.out=Path(repo).resolve(),Path(out).resolve();self.out.mkdir(parents=True,exist_ok=True);self.base=None;self.pid=None;self.env={**os.environ,'SELF_MEDIA_STATE_DIR':str(self.out/'state'),'SELF_MEDIA_DATA_DIR':str(self.out/'data'),'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'}
    def cli(self,name,args):
        dest=self.out/(name+'.json');cmd=[sys.executable,'-B',str(self.repo/'workbench.py'),'--out',str(dest),*args];p=subprocess.run(cmd,cwd=self.repo,env=self.env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180);write(self.out/(name+'-process.json'),{'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode();return read(dest)
    def request(self,name,method,path,body=None,expected=200):
        q=urllib.request.Request(self.base+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'},method=method)
        try:
            with urllib.request.urlopen(q,timeout=180) as r:status=r.status;data=json.load(r)
        except urllib.error.HTTPError as e:
            status=e.code;raw=e.read()
            try:data=json.loads(raw)
            except Exception:data=raw.decode(errors='replace')
        write(self.out/(name+'.json'),{'request':{'method':method,'path':path,'body':body},'status':status,'response':data})
        if expected is not None and status!=expected:raise RuntimeError(f'{name}: expected{expected}, actual{status}: {data}')
        return data if expected is not None else (status,data)
    def context(self,name):return self.request(name,'GET',f'/api/agent/v1/projects/{self.pid}/context')
    def compile_save(self,name,request):
        ctx=self.context(name+'-context');b=copy.deepcopy(request);b.update(request_id='independent-'+uuid.uuid4().hex,project_revision=ctx['project']['revision'],supersedes=ctx['project'].get('timeline_head'));write(self.out/(name+'-compile-request.json'),b);result=self.request(name+'-compile','POST',f'/api/projects/{self.pid}/talking-profile/compile',b);plan=result['timeline_plan'];saved=self.request(name+'-save','POST',f'/api/projects/{self.pid}/timeline-plans',plan);assert plan==saved['request'];return saved
    def export(self,name,plan):
        job=self.request(name+'-submit','POST',f'/api/projects/{self.pid}/timeline/export',{'plan_id':plan['id']})
        for n in range(600):
            job=self.request(f'{name}-poll-{n:03}','GET',f'/api/projects/{self.pid}/jobs/{job["id"]}')
            if job['status'] in ('done','failed','error'):
                write(self.out/(name+'-terminal.json'),job)
                if job['status']!='done':raise RuntimeError(str(job))
                return self.out/'data'/self.pid/'exports'/job['result']['export_id']/'timeline.mp4'
            time.sleep(1)
        raise TimeoutError(name)
