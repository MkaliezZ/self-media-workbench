"""Supplement original source/text fidelity and cue boundaries without product imports."""
from pathlib import Path
import argparse,numpy as np
from PIL import Image,ImageFilter
from client import read,write
from measure_case import warp_card
import decode_media as media
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--materials',type=Path,default=Path(__file__).parent/'materials');a=p.parse_args();idx=read(a.out/'exports-index.json');selected={89,90,210,330,450,480};ordinary,_=media.frames(idx['versions']['ordinary']['video'],selected);plain,_=media.frames(idx['versions']['no-texture']['video'],selected);advanced,_=media.frames(idx['versions']['advanced']['video'],selected);effect=read(a.out/'advanced-save.json')['response']['request']['effects'][0];card=Image.open(a.materials/'own_alpha_card.png').convert('RGBA');checks=[]
    for n,key in zip([90,210,330,450],effect['keys'][:4]):
        expected,_=warp_card(card,key['quad']);alpha=np.array(expected.getchannel('A').filter(ImageFilter.MinFilter(5)))>250;actual=plain[n].astype(float);source=np.array(expected)[:,:,:3].astype(float);mae=float(np.abs(actual[alpha]-source[alpha]).mean());checks.append({'check':f'original-opaque-source-including-text-{n}','pass':mae<10,'opaque_mean_absolute_error':mae,'compared_pixels':int(alpha.sum())})
    for n in [89,480]:
        value=media.rmse(advanced[n],ordinary[n]);checks.append({'check':f'effect-absent-at-frame-{n}','pass':value<.5,'whole_frame_rgb_rmse':value})
    result={'all_pass':all(v['pass'] for v in checks),'checks':checks,'scope':'Original glyphs/number/order checked through source-pixel image error plus manual actual-frame inspection, not OCR or content truth'};write(a.out/'decoded-evidence'/'source-pixels-and-boundaries.json',result);print(result)
if __name__=='__main__':main()
