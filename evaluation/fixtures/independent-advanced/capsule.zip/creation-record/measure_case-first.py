"""Independent source-pixel/PCM and frozen-plan checks, not perceptual scoring."""
from pathlib import Path
import argparse,json,hashlib,math,subprocess
import numpy as np
from PIL import Image,ImageDraw
import decode_media as media
from client import read,write
ROOT=Path(__file__).resolve().parent
def warp_card(card,q):
    # Solve target->source planar mapping independently from the product.
    target=np.array([[p['x']*1280,p['y']*720] for p in q]);source=np.array([[0,0],[card.width,0],[card.width,card.height],[0,card.height]],float);rows=[];values=[]
    for (x,y),(u,v) in zip(target,source):rows.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);values.extend([u,v])
    coeff=np.linalg.solve(np.asarray(rows),np.asarray(values));warped=card.transform((1280,720),Image.Transform.PERSPECTIVE,coeff,Image.Resampling.BICUBIC);inverse=np.linalg.inv(np.array([[*coeff[:3]],[*coeff[3:6]],[coeff[6],coeff[7],1]]));centre=inverse@np.array([360,240,1]);return warped,centre[:2]/centre[2]
def main(out):
    out=out.resolve();idx=read(out/'exports-index.json');ev=out/'decoded-evidence';ev.mkdir(exist_ok=True);selected={0,60,89,90,120,180,210,240,300,330,360,420,450,479,480,539};frames={};checks=[]
    def add(name,passed,**data):checks.append({'check':name,'pass':bool(passed),**data})
    for name,item in idx['versions'].items():
        p=Path(item['video']);probe=media.probe(p);write(ev/(name+'-ffprobe.json'),probe);v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio');add(name+'-clock',v['nb_read_frames']=='540' and v['avg_frame_rate']=='30/1' and abs(float(v['duration'])-18)<1e-5 and abs(float(a['duration'])-18)<=1/30,frames=v['nb_read_frames'],video_seconds=v['duration'],audio_seconds=a['duration']);frames[name],count=media.frames(p,selected)
    request=read(out/'advanced-save.json')['response']['request'];effect=request['effects'][0];card=Image.open(ROOT/'materials'/'own_alpha_card.png').convert('RGBA')
    for time,key in zip([3,7,11,15],effect['keys'][:4]):
        frame=round(time*30);actual=frames['no-texture'][frame];background=frames['ordinary'][frame];expected,hole=warp_card(card,key['quad']);bbox=expected.getchannel('A').point(lambda v:255 if v>=128 else 0).getbbox();a=actual.astype(int);orange=(a[:,:,0]-a[:,:,1]>45)&(a[:,:,1]-a[:,:,2]>40)&(np.max(abs(a-background.astype(int)),axis=2)>25);ys,xs=np.where(orange)
        observed=[int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1)] if len(xs) else None;error=max(abs(observed[i]-bbox[i]) for i in range(4)) if observed else 999
        add('actual-middle-key-'+str(time),error<=8,source_expected_opaque_bbox=list(bbox),observed_orange_border_bbox=observed,max_boundary_error_px=error)
        x,y=np.round(hole).astype(int);roi=frames['advanced'][frame][y-4:y+5,x-4:x+5];bg=background[y-4:y+5,x-4:x+5];mae=float(np.mean(abs(roi.astype(float)-bg.astype(float))));magenta=int(((roi[:,:,0]>200)&(roi[:,:,2]>180)&(roi[:,:,1]<70)).sum());add('alpha-hole-'+str(time),mae<6 and magenta==0,projected_hole_center=[float(z) for z in hole],background_mae=mae,magenta_pixels=magenta)
    # Independent actual edge slopes at the perspective key, not just bbox.
    a=frames['no-texture'][210].astype(int);bg=frames['ordinary'][210].astype(int);mask=(a[:,:,0]-a[:,:,1]>45)&(a[:,:,1]-a[:,:,2]>40)&(np.max(abs(a-bg),axis=2)>25);samples=[]
    for x in [820,1060]:
        ys,xs=np.where(mask[90:155,x-2:x+3]);samples.append(float(np.median(ys+90)) if len(ys) else None)
    add('positive-perspective-edge',all(v is not None for v in samples) and samples[0]-samples[1]>8,top_edge_y_samples=samples)
    # Same original opaque flat patch, at the first unwarped authored pose.
    roi=(slice(492,506),slice(110,160));plain=frames['no-texture'][90][roi].astype(float);vignette=frames['vignette-only'][90][roi].astype(float);grain=frames['grain-only'][90][roi].astype(float)
    ratio=float(vignette.mean()/plain.mean());noise=grain-plain;noise_std=float(np.std(noise.mean(axis=2)));add('independent-vignette',ratio<.96,mean_luminance_ratio=ratio);add('independent-grain',noise_std>2,flat_patch_difference_std=noise_std)
    temporal_plain=frames['no-texture'][450][roi].astype(float)-plain;temporal_grain=frames['grain-only'][450][roi].astype(float)-grain;add('grain-is-nonstatic',float(np.std(temporal_grain))>float(np.std(temporal_plain))+2,grain_temporal_std=float(np.std(temporal_grain)),plain_temporal_std=float(np.std(temporal_plain)))
    revised=media.rmse(frames['advanced'][210],frames['revised'][210]);add('actual-revision-changed',revised>3,frame7_rgb_rmse=revised)
    audio_reference=media.pcm(ROOT/'materials'/'own_narrated_source.mp4')
    for name in ['ordinary','advanced','restored']:
        audio=media.pcm(idx['versions'][name]['video']);duration=min(len(audio),len(audio_reference));correlation=media.corr(audio[:duration],audio_reference[:duration]);peak=float(abs(audio).max());rms=float(np.sqrt(np.mean(audio*audio)));add(name+'-actual-voice',peak>.05 and rms>.01 and correlation>.98,peak=peak,rms=rms,source_correlation=correlation,audio_seconds=len(audio)/8000)
    add('restored-bit-identical',idx['versions']['advanced']['sha256']==idx['versions']['restored']['sha256'],first_sha256=idx['versions']['advanced']['sha256'],restored_sha256=idx['versions']['restored']['sha256'])
    # Independently check actual frozen copies and compiler request equality.
    manifest_results=[]
    for name in ['ordinary','advanced','restored']:
        record=read(out/(name+'-save.json'))['response'];compiled=read(out/(name+'-compile.json'))['response']['timeline_plan'];folder=out/'data'/idx['project_id']/'timeline-plans'/record['id'];same=compiled==record['request'];hashes=all(hashlib.sha256((folder/s['relative_path']).read_bytes()).hexdigest()==s['sha256'] for s in record['sources']);profile=record['request']['production_profile'];definition=hashlib.sha256(json.dumps(profile['profile'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest();profile_ok=definition==profile['definition_sha256'];manifest_results.append({'version':name,'compiled_saved_exact':same,'source_frozen_hashes_match':hashes,'profile_definition_hash_matches':profile_ok,'profile_id':profile['profile']['id'],'keyframe_count':len(record['request']['effects'][0]['keys']) if name!='ordinary' else 0});add(name+'-frozen-manifest',same and hashes and profile_ok,**manifest_results[-1])
    ids=[0,90,180,210,300,330,420,450];sheet=Image.new('RGB',(1280,390*math.ceil(len(ids)/2)),'#dce6e9')
    for k,n in enumerate(ids):
        im=Image.fromarray(frames['advanced'][n]);im.thumbnail((640,360));x,y=(k%2)*640,(k//2)*390;sheet.paste(im,(x,y));ImageDraw.Draw(sheet).text((x+10,y+367),f'ACTUAL advanced frame{n} / {n/30:.3f}s',fill='#203e4e')
    sheet.save(ev/'actual-advanced-contact-sheet.jpg',quality=95)
    for name in ['ordinary','advanced','no-texture','vignette-only','grain-only','revised','restored']:Image.fromarray(frames[name][210]).save(ev/(name+'-frame0210.png'))
    result={'all_measurements_pass':all(c['pass'] for c in checks),'checks':checks,'frozen_manifests':manifest_results,'scope':'Real source pixels, declared synthetic speech PCM and frozen decisions. No human listening/artistic or ASR alignment claim.'};write(ev/'measurements.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);main(p.parse_args().out)
