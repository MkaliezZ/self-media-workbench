from pathlib import Path
import copy,json,subprocess,uuid,argparse
from client import Client,read,write
ROOT=Path(__file__).resolve().parent
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,default=ROOT/'product-snapshot-01');parser.add_argument('--out',type=Path,default=ROOT/'attempts'/'negative-snapshot-01');parser.add_argument('--authored',type=Path,default=ROOT/'attempts'/'001-snapshot-01');a=parser.parse_args();out=a.out.resolve();out.mkdir();neg=out/'negative-inputs';neg.mkdir();quiet=neg/'zero_pcm_narration.mp4';subprocess.run(['ffmpeg','-y','-v','error','-i',str(ROOT/'materials'/'own_silent_animation_1280x720_25fps.mp4'),'-f','lavfi','-i','anullsrc=r=48000:cl=mono','-map','0:v','-map','1:a','-c:v','copy','-c:a','aac','-t','18',str(quiet)],check=True)
    c=Client(a.repo,out);args=['run','独立负测：验证静音/零PCM不应被编译成口播，来源和关键帧错误应拒绝','--intent','edit','--new','--title','Independent talking negative validation','--simulation','--media-nature','generated','--source-note','Original synthetic diagnostic inputs, including explicitly silent and zero-PCM negative fixtures','--session','advanced-negative']
    for p in [ROOT/'materials'/'own_narrated_source.mp4',ROOT/'materials'/'own_silent_animation_1280x720_25fps.mp4',ROOT/'materials'/'own_alpha_card.png',quiet]:args.extend(['--input',str(p)])
    intake=c.cli('intake',args);c.base,c.pid=intake['service_url'],intake['project_id'];ctx=c.context('initial-context');media={x['name']:x for x in ctx['project']['media']};card=ctx['project']['image_assets'][0];profiles=c.request('catalog','GET','/api/visual/talking-profiles')['profiles'];adv=read(a.authored/'authored-advanced.json');ordinary=read(a.authored/'authored-ordinary.json');results=[]
    for name in ['ordinary-no-audio','advanced-no-audio','ordinary-zero-pcm','advanced-zero-pcm','missing-evidence','unknown-evidence','missing-material-note','duplicate-keys','reverse-keys','beyond-key-time','zero-crop','self-cross-quad','far-off-canvas','effect-overrun','ordinary-with-advanced','advanced-without-effects','source-hash-mismatch']:
        b=copy.deepcopy(ordinary if name.startswith('ordinary') else adv);definition=next(p for p in profiles if p['id']==b['profile_id']);b.update(profile_version=definition['version'],profile_sha256=definition['definition_sha256']);is_ordinary=b['profile_id']=='ordinary_talking_head';video=media['own_narrated_source.mp4']
        if name.endswith('no-audio'):video=media['own_silent_animation_1280x720_25fps.mp4']
        if name.endswith('zero-pcm'):video=media['zero_pcm_narration.mp4']
        b['sources']=[{'id':'narrated','kind':'media','asset_id':video['id'],'sha256':video['sha256']}]
        if not is_ordinary or name=='ordinary-with-advanced':b['sources'].append({'id':'card','kind':'image','asset_id':card['id'],'sha256':card['sha256']})
        e=b['scenes'][0]['effects'][0] if b['scenes'][0]['effects'] else None
        if name=='missing-evidence':b['scenes'][0]['evidence_source_id']=None
        elif name=='unknown-evidence':b['scenes'][0]['evidence_source_id']='not-displayed'
        elif name=='missing-material-note':b['scenes'][0]['material_note']=''
        elif name=='duplicate-keys':e['keys'][2]['at']=e['keys'][1]['at']
        elif name=='reverse-keys':e['keys'][1]['at']=9
        elif name=='beyond-key-time':e['keys'][-1]['at']=14
        elif name=='zero-crop':e['crop']['width']=0
        elif name=='self-cross-quad':e['keys'][1]['quad'][2],e['keys'][1]['quad'][3]=e['keys'][1]['quad'][3],e['keys'][1]['quad'][2]
        elif name=='far-off-canvas':e['keys'][1]['quad'][0]['x']=6
        elif name=='effect-overrun':e['end']=19
        elif name=='ordinary-with-advanced':b['scenes'][0]['effects']=copy.deepcopy(adv['scenes'][0]['effects'])
        elif name=='advanced-without-effects':b['scenes'][0]['effects']=[];b['scenes'][0].update(claim_kind='illustration',evidence_source_id=None);b['sources']=b['sources'][:1]
        elif name=='source-hash-mismatch':b['sources'][0]['sha256']='0'*64
        fresh=c.context(name+'-context');b.update(request_id='negative-'+uuid.uuid4().hex,project_revision=fresh['project']['revision'],supersedes=fresh['project'].get('timeline_head'));status,response=c.request(name+'-compile','POST',f'/api/projects/{c.pid}/talking-profile/compile',b,expected=None);results.append({'case':name,'status':status,'accepted':status==200})
    after=c.context('after-context');result={'cases':results,'head_unchanged':ctx['project'].get('timeline_head')==after['project'].get('timeline_head'),'revision_unchanged':ctx['project']['revision']==after['project']['revision'],'no_render_jobs':len(after['jobs'])==0,'quiet_input':str(quiet)};write(out/'summary.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
