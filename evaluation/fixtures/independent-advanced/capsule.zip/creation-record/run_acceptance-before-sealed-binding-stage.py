"""Native, self-contained source-swapped acceptance; no models or hosted services."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,platform,shutil,subprocess,sys,traceback,venv
ROOT=Path(__file__).resolve().parent
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repo',type=Path,required=True);parser.add_argument('--out',type=Path,required=True);a=parser.parse_args();repo=a.repo.resolve();out=a.out.resolve()
    if not (repo/'workbench.py').is_file():raise ValueError('Expected the actual product repository containing workbench.py')
    if not os.environ.get('INDEPENDENT_CAPSULE_BOOTSTRAPPED'):
        if out.exists():raise ValueError('--out must be new; existing evidence is never overwritten')
        out.mkdir(parents=True)
        # Reuse actual interpreter when sufficient. Otherwise create an isolated
        # runtime inside this run directory, with no global package mutation.
        required=['numpy','PIL','psutil','fastapi','uvicorn','pydantic'];python=sys.executable
        if any(importlib.util.find_spec(n) is None for n in required):
            runtime=out/'.runtime';venv.EnvBuilder(with_pip=True).create(runtime);python=str(runtime/('Scripts/python.exe' if os.name=='nt' else 'bin/python'));cmd=[python,'-m','pip','install','-r',str(repo/'requirements.txt'),'psutil>=5,<8'];r=subprocess.run(cmd,capture_output=True,text=True);write(out/'dependency-setup.json',{'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});r.check_returncode()
        env={**os.environ,'INDEPENDENT_CAPSULE_BOOTSTRAPPED':'1','PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1'}
        for name in ['ffmpeg','ffprobe']:
            if not shutil.which(name):
                # Agent may supply a process-local PATH. Do not rewrite global
                # settings or install unrelated GPU/ASR runtimes.
                raise RuntimeError(f'{name} unavailable; the calling Agent must install the documented native FFmpeg prerequisite, then use a new output directory')
        result=subprocess.run([python,str(Path(__file__).resolve()),'--repo',str(repo),'--out',str(out)],env=env);return result.returncode
    from client import read
    failures=[];manifest=read(ROOT/'materials'/'manifest.json');hashes={n:hashlib.sha256((ROOT/'materials'/n).read_bytes()).hexdigest()==v['sha256'] for n,v in manifest['files'].items()};write(out/'sealed-input-check.json',hashes)
    if not all(hashes.values()):raise RuntimeError('Sealed original input hash mismatch')
    def capture(args):
        r=subprocess.run(args,cwd=repo,capture_output=True,text=True,encoding='utf-8',errors='replace');return {'command':args,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    versions={n:capture([n,'-version']) for n in ['ffmpeg','ffprobe']};fingerprints={}
    for p in (repo/'backend').glob('*.py'):fingerprints[p.relative_to(repo).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    write(out/'native-runtime.json',{'platform':platform.platform(),'machine':platform.machine(),'python':sys.version,'native_execution':True,'emulation_claim':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'git_head':capture(['git','rev-parse','HEAD']),'git_status':capture(['git','status','--short']),'backend_sha256':fingerprints,'executables':versions})
    positive=out/'positive';negative=out/'negative'
    commands=[('render',[str(ROOT/'run_native_case.py'),'--repo',str(repo),'--out',str(positive)]),('negative',[str(ROOT/'probe_validation.py'),'--repo',str(repo),'--out',str(negative),'--authored',str(positive)]),('measure',[str(ROOT/'measure_case.py'),'--out',str(positive)]),('source-pixels',[str(ROOT/'check_source_pixels.py'),'--out',str(positive)]),('restart',[str(ROOT/'check_resume.py'),'--repo',str(repo),'--out',str(positive)])]
    try:
        for name,args in commands:
            print('EXECUTING',name,flush=True);record=capture([sys.executable,'-B',*args]);write(out/(name+'-process.json'),record)
            if record['returncode']:raise RuntimeError(f'{name} failed; inspect its retained process record')
        measures=read(positive/'decoded-evidence'/'measurements.json');pixels=read(positive/'decoded-evidence'/'source-pixels-and-boundaries.json');neg=read(negative/'summary.json');restart=read(positive/'restart-summary.json');neg_ok=all(v['status']==(409 if v['case']=='source-hash-mismatch' else 422) for v in neg['cases']) and all(neg[k] for k in ['head_unchanged','revision_unchanged','no_render_jobs']);passed=measures['all_measurements_pass'] and pixels['all_pass'] and neg_ok and restart['all_pass'];write(out/'RESULT.json',{'status':'PASS' if passed else 'FAIL','positive_measurements':measures['all_measurements_pass'],'source_pixels_and_cue_boundaries':pixels['all_pass'],'negative_cases':len(neg['cases']),'negative_invariants':neg_ok,'real_service_restart_and_reexport':restart['all_pass'],'scope':'Native technical execution only. No human listening, ASR word alignment, aesthetic judgement, real-person or 90-second-main-showcase acceptance. Historical pre-fix zero-PCM plan is separately preserved in the original Windows evidence; this capsule does not invent old history.'});return 0 if passed else 1
    except Exception:
        write(out/'RESULT.json',{'status':'FAIL','error':traceback.format_exc(),'scope':'Actual attempted execution; previous outputs and errors retained'});raise
    finally:
        # Only shut down processes proven to belong to this capsule's isolated
        # state and actual repository; never touch another user's service.
        import psutil
        stopped=[]
        for folder in [positive,negative]:
            for state in (folder/'state'/'services').glob('*.json'):
                info=read(state)
                try:
                    process=psutil.Process(info['pid']);command=process.cmdline()
                    if Path(info['root']).resolve()==repo and str(repo/'workbench.py') in command and 'serve' in command:process.terminate();process.wait(timeout=30);stopped.append({'pid':info['pid'],'owned_service_stopped':True})
                except psutil.NoSuchProcess:pass
        write(out/'owned-service-cleanup.json',stopped)
if __name__=='__main__':sys.exit(main())
