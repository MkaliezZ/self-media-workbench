"""Original source-bound ordinary/advanced narration acceptance, no showcase."""
from pathlib import Path
import argparse,copy,hashlib,json,traceback
from client import Client,read,write
ROOT=Path(__file__).resolve().parent
def quad(rect,local=None):
    x,y,w,h=rect;local=local or [(0,0),(1,0),(1,1),(0,1)];return [{'x':(x+a*w)/1280,'y':(y+b*h)/720} for a,b in local]
def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();c=Client(a.repo,a.out)
    args=['run','高级口播独立新素材验收：真实AI旁白，四关键帧往返、正向透视、alpha洞、暗角与颗粒；保留干净普通口播对照，实际编译导出和续做','--intent','edit','--new','--title','Independent original weather-inspection narration','--simulation','--media-nature','generated','--source-note','Original illustrated source and own locally synthesized AI narration; no real person, reference account or source clip','--usage-scope','Independent technical acceptance, not perceptual listening or factual weather data','--session','advanced-talking-blind']
    for name in ['own_narrated_source.mp4','own_alpha_card.png','narration_source.txt','source_evidence.json']:args.extend(['--input',str(ROOT/'materials'/name)])
    intake=c.cli('intake',args);c.base,c.pid=intake['service_url'],intake['project_id'];cat=c.request('actual-catalog','GET','/api/visual/talking-profiles')['profiles'];c.cli('actual-talking-schema',['schema','talking-profile']);ctx=c.context('initial-context');video=next(x for x in ctx['project']['media'] if x['name']=='own_narrated_source.mp4');card=next(x for x in ctx['project']['image_assets'] if x['label']=='own_alpha_card.png');source=read(ROOT/'materials'/'source_evidence.json');speech=source['narration_text'];duration=source['film_duration_seconds']
    refs=[{'id':'narrated','kind':'media','asset_id':video['id'],'sha256':video['sha256']},{'id':'card','kind':'image','asset_id':card['id'],'sha256':card['sha256']}]
    perspective=source['positive_perspective_at_7'];rects=source['keyframe_rects_pixels'];keys=[{'at':t-3,'quad':quad(r,perspective if t==7 else None),'opacity':1,'blur':0} for t,r in zip([3,7,11,15],rects)];keys.append({'at':13,'quad':quad(rects[-1]),'opacity':1,'blur':0})
    effect={'kind':'keyframe_layer','source_id':'card','start':3,'end':16,'reason':'Original 07 card, true middle keys, positive perspective and returned alpha hole','crop':{'x':0,'y':0,'width':1,'height':1},'keys':keys,'easing':'linear','shadow':False,'vignette':.28,'grain':.035}
    common={'request_id':'draft','project_revision':ctx['project']['revision'],'supersedes':None,'revision_reason':'Independent real synthetic-narration source, no fake ASR IDs','intent':'Source-pixel and actual-voice inspection, not an artistic or real-person claim','width':1280,'height':720,'fps':30,'sources':refs,'audio':[],'titles':[]}
    def request(profile,effects):
        definition=next(x for x in cat if x['id']==profile);b=copy.deepcopy(common);b.update(profile_id=profile,profile_version=definition['version'],profile_sha256=definition['definition_sha256']);b['scenes']=[{'shot':{'id':'inspection','source_id':'narrated','source_in':0,'source_out':duration,'role':'evidence' if effects else 'anchor','reason':'Actual original illustrated narration source','fit':'contain','source_audio_gain':1},'mode':'evidence' if effects else 'anchor','spoken_text':speech,'purpose':'Inspect actual original card pixels, return path and declared AI voice' if effects else 'Keep the same declared AI narration clean','material_note':'Self-authored synthetic video/card and offline AI narration; text/source evidence files registered; no real weather data or human listening claim','claim_kind':'evidence' if effects else 'illustration','evidence_source_id':'card' if effects else None,'headline':'','effects':effects}]
        if not effects:b['sources']=[refs[0]]
        return b
    ordinary=request('ordinary_talking_head',[]);advanced=request('advanced_talking_head',[effect]);write(c.out/'authored-ordinary.json',ordinary);write(c.out/'authored-advanced.json',advanced);index={'project_id':c.pid,'service_url':c.base,'versions':{}}
    variants=[('ordinary',ordinary),('advanced',advanced)]
    for name,request_body in variants:
        saved=c.compile_save(name,request_body);path=c.export(name+'-export',saved);index['versions'][name]={'video':str(path),'plan_id':saved['id'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};write(c.out/'exports-index.json',index)
    # Controls isolate two actual finish components, rather than treating their
    # preset names or combined appearance as independent evidence.
    for name,vignette,grain in [('no-texture',0,0),('vignette-only',.28,0),('grain-only',0,.035)]:
        b=copy.deepcopy(advanced);b['scenes'][0]['effects'][0].update(vignette=vignette,grain=grain);b['revision_reason']='Independent same-time texture control: '+name;saved=c.compile_save(name,b);path=c.export(name+'-export',saved);index['versions'][name]={'video':str(path),'plan_id':saved['id'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};write(c.out/'exports-index.json',index)
    changed=copy.deepcopy(advanced);changed['scenes'][0]['effects'][0]['keys'][1]['quad']=quad([790,100,360,240],perspective);changed['scenes'][0]['effects'][0]['grain']=.055;changed['revision_reason']='Real revised middle-key position and grain, preserve first movie';saved=c.compile_save('revised',changed);path=c.export('revised-export',saved);index['versions']['revised']={'video':str(path),'plan_id':saved['id'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};write(c.out/'exports-index.json',index)
    restored=copy.deepcopy(advanced);restored['revision_reason']='Restore original authored decision through current head as new version';saved=c.compile_save('restored',restored);path=c.export('restored-export',saved);index['versions']['restored']={'video':str(path),'plan_id':saved['id'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};write(c.out/'exports-index.json',index);print('ORDINARY, ADVANCED, CONTROLS, REVISION AND RESTORE EXPORTED')
if __name__=='__main__':
    try:main()
    except Exception:
        import sys
        error=traceback.format_exc();(ROOT/'last-driver-error.txt').write_text(error,encoding='utf-8');raise
