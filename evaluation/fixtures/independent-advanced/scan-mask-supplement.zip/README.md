# Independent scan/mask Supplement

这是单独封存的小范围验收，原18秒case与报告不变。执行Agent阅读SEALED-SUPPLEMENT.md，然后通过当前原生Python运行run_supplement.py，传入实际工作台--repo与全新--out；该驱动自动通过统一task入口启动隔离服务，发现catalog/schema，真实编译/保存/导出三版并做五项拒绝。随后用同一--out运行measure_supplement.py，读取decoded/RESULT.json和实际抽帧。依赖为工作台requirements、FFmpeg/ffprobe及Pillow/numpy；由Agent按产品README管理，用户不必记命令。已有--out会拒绝覆盖。

素材是本次新自制插画、PNG alpha窗、动画与已声明AI旁白。固定输入和任务哈希在SEALED-SUPPLEMENT-MANIFEST.json；generate_assets.py只作Windows创作来源记录，不在跨平台执行链运行，不需在Mac重新生成同音色或加载Windows字体。包不含任何字体二进制/模型/原输出/产品代码。所有执行脚本均使用相邻materials与参数路径，没有F盘或历史repo依赖。

首次驱动的unused-source拒绝和初版反相阈值不对称比较器均保留；原始错误数据在本机完整报告目录，不伪造为产品失败。Windows实际结果见REPORT-SUPPLEMENT.md；Mac待用户样片验收后另跑，不继承Windows成绩。master_audio、人工听审、审美、ASR和主90秒片均不在本轮范围。没有push或CI。
