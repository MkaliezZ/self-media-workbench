# Supplement：Windows实际导出技术PASS

此为独立追加范围，不修改原封存18秒case、两份原报告或其成绩。新素材和判据在2026-10-25T18:11:44Z封存后再读取具体schema，原始哈希见SEALED-SUPPLEMENT-MANIFEST.json。新自制ALPHA 07 / SOURCE 19原像素页面、绿紫透明窗、动态背景与已声明本机AI语音，不复用主90秒素材。PRODUCT-FINGERPRINT.json确认当前根仓库全部backend源码与先前不可变product-snapshot-02完全相同；运行使用该隔离snapshot，没有修改产品。

| 封存检查 | 实际证据 |
|---|---|
| 三版真实导出 | 对照、multiply、invert均为1280×720/30fps/360帧/12秒，实际终态done。PCM RMS0.05794、与新原旁白源相关0.999993，不以音轨存在代替声音。 |
| 原字形及源像素 | 对照原始PNG裁剪/投影像素MAE1.623；multiply完成行与原像素乘FFE66B的MAE1.94–2.33，字形IoU0.931–0.954；invert与255减原像素的MAE1.14–1.32，字形IoU0.981–0.991。编号、字序、原像素保留，非重新生成文字或用不透明块遮字。 |
| 扫描过程 | 0.5秒前行区与未处理对照MAE≤0.194；2秒上行改变约48.3%/50.1%、下行近0%；4秒上行约98.3%/99.85%、下行48.0%/50.1%，符合先上后下并有部分扫描状态。 |
| 扫完保持 | 6秒与11秒两行仍为完整乘色/反相，源变换像素检查都过；两时刻行区MAE仅0.34–0.89，没有闪回。框外青条MAE≤0.225。 |
| compile.masks真实成片 | 已登记PNG在crop(.1,.1,.8,.8)后进入右侧300×300矩形框。左绿实际RGB78/204/152、右紫152/101/216，源色MAE≤2；crop外红边像素0，输出框外MAE0。 |
| 原始alpha洞 | 0.5/6/11秒洞内对同期无mask背景MAE≤0.766，隐藏洋红0像素。真实移动黄色圆点从洞后经过，透明洞未被填色。 |
| 冻结与源绑定 | compile的timeline_plan与save.request完全相同；mask的源ID、crop、slot、时钟、shape/opacity未漂移；所有冻结原件哈希匹配，原透明窗SHA256为65bc82127ba6c72221f71d89b398bab413465959544bdee393fd0e27164c3871。 |
| 拒绝与状态 | 选区部分在crop外、全在crop外、未知mask源、非法mask crop均422；错误mask源哈希409。有效head/revision/jobs完全不变。 |
| 封存原件 | 全部封存文件字节哈希未变。 |

没有发现需要修改产品的问题。所有实际请求、原输入、保存方案、frozen copies、MP4及抽帧保留在attempt02。主要证据：attempt02/decoded/RESULT.json、actual-scans-and-alpha-window.jpg、negative-summary.json、exports-index.json，以及逐项compile/save/export-terminal记录。

## 保留的首次失败与修订

首次驱动把未使用的窗来源也带入无mask对照，被产品正确422拒绝“Unused registered source”。attempt01/control-compile.json及run_supplement-attempt01.py保留。只修驱动对照来源列表，在全新attempt02重新运行；未改产品、封存任务或素材。

初版反相字形比较器将输入白字阈值>220，却拿输出<60进行IoU比较，二者不是255反相后的同一阈值，误报四项字形失败；逐像素反相MAE其实始终仅1.14–1.32。修为对应输出<35后，原IoU>0.92标准不变，实际IoU0.981–0.991。初版脚本measure_supplement-first.py和attempt02/decoded/RESULT-first-comparator.json保留，最终报告没有将比较器错误算产品缺陷，也没有隐去首次记录。

## 范围边界

仅Windows原生技术验收。Mac仍NOT_TESTED，待用户样片通过后另行原生CI；没有push或触发CI。不代表主90秒样片、审美、人工听审、人声真实性或ASR词级对齐。本轮没有调用master_audio.py，后处理明确NOT_TESTED。静态页面、窗口和背景为原创诊断插画，旁白为本机合成，不是真人、参考账号、原片或真实气象事实。

run_supplement.py和measure_supplement.py使用--repo/--out、相邻materials和本机FFmpeg，运行不需Windows字体或历史导出；只有生成器创作记录使用标准Windows字体。依赖由调用Agent按照工作台README管理，不要求最终用户记命令。此处不携带字体文件、模型或主片。
