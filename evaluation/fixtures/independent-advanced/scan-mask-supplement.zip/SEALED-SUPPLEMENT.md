# 单独 Supplement：扫描高亮/反相与 compile.masks

本任务不改变原独立18秒任务、素材、报告或成绩。先封存此新素材与判据，再读本轮具体schema。全部为自制诊断插画和已声明本机AI语音，不使用主90秒素材、主测试或主展示答案。不修改产品代码、不push；master_audio后处理明确未测。

1. 新背景视频保留原声AI语音，分别真实编译/保存/导出无处理对照、multiply扫描、invert扫描。以source_evidence的时长/fps为准，实际文件应同钟、完整PCM，不把API200当导出成功。
2. 两行原始白字ALPHA 07 / SOURCE 19来自original_scan_sheet.png，采用源crop(.1,.1,.8,.8)和封存两行框，输出位置见source_evidence。扫描延迟1秒、总扫过4秒。0.5秒前未高亮；过程中先上行后下行，有中间部分覆盖；6秒和倒数1秒两行均保持完成，不得闪回。原文与字形须保留：multiply为真实原像素乘黄色而非覆盖不透明黄块；invert为原白字变暗、原暗底变亮，字序和非框区不变。
3. 使用talking-profile.compile.masks把已登记original_alpha_window.png编译到原生导出。它有真实透明洞（alpha0且隐藏RGB为洋红）、左绿右紫，以及位于crop外的红边。按封存crop和右侧300×300输出框实际合成：孔后必须与同期无mask背景一致，不得漏洋红；左右色块方向正确、红色crop外边不可出现；源PNG哈希必须进入冻结manifest，编译前后crop/源绑定不漂移。与highlight的时间钟一致。
4. 负测至少覆盖highlights选区部分在crop外、全在crop外、错误源哈希、未知mask源和非法mask crop，均应在真实导出前拒绝且不移动已有head、不产生新job。按实际schema支持字段提交；不可虚构未支持的自动抠像/任意曲线。
5. 检查真实帧与源像素、扫描过程、保持、Alpha洞、crop边界及实际PCM；原输入和首失败保留，比较器修订单独记录。Windows独立技术PASS不等于审美、人工听审、人声真实性或Mac通过。Mac待用户样片验收后另行原生运行。
