"""Original diagnostic assets; generation record, not product/test import."""
from pathlib import Path
import numpy as np,json,hashlib,math,subprocess,wave
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent;M=ROOT/'materials'
def main():
    with wave.open(str(M/'declared_ai_scan_voice.wav')) as w:voice_seconds=w.getnframes()/w.getframerate()
    duration=max(12,math.ceil(voice_seconds+1));font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',44)
    page=Image.new('RGBA',(640,400),'#202020');d=ImageDraw.Draw(page);d.rectangle((64,40,575,359),outline='#1fced0',width=3);d.text((112,92),'ALPHA 07',font=font,fill='white');d.text((112,212),'SOURCE 19',font=font,fill='white');d.rectangle((100,315,530,330),fill='#20a2ba');page.save(M/'original_scan_sheet.png')
    mask=Image.new('RGBA',(400,400),(255,0,255,0));d=ImageDraw.Draw(mask);d.rectangle((0,0,399,399),fill='#e63e35');d.rectangle((40,40,199,359),fill='#50ce9a');d.rectangle((200,40,359,359),fill='#9866d9');d.ellipse((155,155,245,245),fill=(255,0,255,0));mask.save(M/'original_alpha_window.png')
    silent=M/'original_moving_background.mp4';p=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r','30','-i','pipe:0','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p',str(silent)],stdin=subprocess.PIPE)
    for n in range(duration*30):
        im=Image.new('RGB',(1280,720),'#16354e');d=ImageDraw.Draw(im);d.rectangle((850,190,1220,550),fill='#bbc8d8');x=1010+40*math.sin(n/30);d.ellipse((x-18,340,x+18,376),fill='#ddbd4b');d.rectangle((0,0,1280,80),fill='#061e2e');p.stdin.write(im.tobytes())
    p.stdin.close();assert p.wait()==0
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(silent),'-i',str(M/'declared_ai_scan_voice.wav'),'-filter_complex',f'[1:a]apad,atrim=duration={duration}[a]','-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-t',str(duration),str(M/'original_narrated_scan_source.mp4')],check=True)
    evidence={'source_nature':'All new original diagnostic illustration, PNG alpha hole and locally synthesized AI speech; no reference person/account/clip','speech_text':'这是独立扫描验证。黄色标记和黑白反相来自原始像素。右侧窗口保留透明洞。','voice_seconds':voice_seconds,'duration':duration,'fps':30,'width':1280,'height':720,'page_crop':{'x':.1,'y':.1,'width':.8,'height':.8},'source_highlight_rects':[{'x':96/640,'y':90/400,'width':432/640,'height':60/400},{'x':96/640,'y':210/400,'width':432/640,'height':60/400}],'page_output_rect_pixels':[80,160,640,400],'mask_source_crop':{'x':.1,'y':.1,'width':.8,'height':.8},'mask_output_rect_pixels':[880,220,300,300],'scan_delay':1,'scan_seconds':4,'texture_processing':False};(M/'source_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),'utf-8');files={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in M.iterdir()};(M/'manifest.json').write_text(json.dumps(files,indent=2),'utf-8');print(evidence)
if __name__=='__main__':main()
