"""Independent source pixel/signal oracle; no product imports."""
from pathlib import Path
import argparse,hashlib,json,math,numpy as np
from PIL import Image,ImageDraw
from client import read,write
import decode_media as media
ROOT=Path(__file__).parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();out=a.out.resolve();s=read(ROOT/'materials'/'source_evidence.json');duration=s['duration'];idx=read(out/'exports-index.json');ev=out/'decoded';ev.mkdir(exist_ok=True);checks=[];frames={};times=[.5,2,4,6,duration-1];selected={round(t*30) for t in times};selected.add(duration*30-1)
    def add(name,passed,**v):checks.append({'check':name,'pass':bool(passed),**v})
    for name,item in idx['versions'].items():
        probe=media.probe(item['video']);write(ev/(name+'-probe.json'),probe);v=next(v for v in probe['streams'] if v['codec_type']=='video');add(name+'-clock',v['nb_read_frames']==str(duration*30) and v['avg_frame_rate']=='30/1' and abs(float(v['duration'])-duration)<1e-6,frames=v['nb_read_frames'],duration=v['duration']);frames[name],_=media.frames(item['video'],selected)
        pcm=media.pcm(item['video']);reference=media.pcm(ROOT/'materials'/'original_narrated_scan_source.mp4');count=min(len(pcm),len(reference));corr=media.corr(pcm[:count],reference[:count]);add(name+'-actual-PCM',np.sqrt(np.mean(pcm*pcm))>.01 and corr>.98 and abs(len(pcm)/8000-duration)<1/30,source_correlation=corr,rms=float(np.sqrt(np.mean(pcm*pcm))))
    # Map sealed original source boxes to their sealed flat output projection.
    cx,cy,cw,ch=[s['page_crop'][k] for k in ['x','y','width','height']];ox,oy,ow,oh=s['page_output_rect_pixels'];regions=[]
    for r in s['source_highlight_rects']:
        x0=ox+(r['x']-cx)/cw*ow;y0=oy+(r['y']-cy)/ch*oh;x1=x0+r['width']/cw*ow;y1=y0+r['height']/ch*oh;regions.append((slice(round(y0)+4,round(y1)-4),slice(round(x0)+4,round(x1)-4)))
    first,last=round(6*30),round((duration-1)*30)
    original=Image.open(ROOT/'materials'/'original_scan_sheet.png').convert('RGB').crop((64,40,576,360)).resize((640,400),Image.Resampling.BICUBIC);source_error=float(abs(frames['control'][first][160:560,80:720].astype(float)-np.array(original).astype(float)).mean());add('control-uses-original-source-typography',source_error<8,original_source_crop_rgb_mae=source_error)
    for mode in ['multiply','invert']:
        for k,roi in enumerate(regions):
            pre=frames[mode][15][roi].astype(float);control_pre=frames['control'][15][roi].astype(float);pre_mae=float(abs(pre-control_pre).mean());add(mode+f'-line{k}-before-delay',pre_mae<3,mae=pre_mae)
            at2=frames[mode][60][roi].astype(float);base2=frames['control'][60][roi].astype(float);ratio=float((abs(at2-base2).max(axis=2)>12).mean());add(mode+f'-line{k}-partial-scan',.1<ratio<.9 if k==0 else ratio<.01,changed_fraction=ratio)
            at4=frames[mode][120][roi].astype(float);base4=frames['control'][120][roi].astype(float);ratio4=float((abs(at4-base4).max(axis=2)>12).mean());add(mode+f'-line{k}-scan-progress-at-4',ratio4>.9 if k==0 else .1<ratio4<.9,changed_fraction=ratio4)
            for frame in [first,last]:
                control=frames['control'][frame][roi].astype(float);actual=frames[mode][frame][roi].astype(float);expected=control*np.array([255,230,107])/255 if mode=='multiply' else 255-control;error=float(abs(actual-expected).mean());white=control.min(axis=2)>220;observed=(actual[:,:,0]>200)&(actual[:,:,1]>160) if mode=='multiply' else actual.max(axis=2)<35;iou=float((white&observed).sum()/max(1,(white|observed).sum()));add(mode+f'-line{k}-source-glyph-{frame}',error<8 and iou>.92,original_pixel_transform_mae=error,glyph_iou=iou,original_white_pixels=int(white.sum()))
            stability=float(abs(frames[mode][first][roi].astype(float)-frames[mode][last][roi].astype(float)).mean());add(mode+f'-line{k}-finished-holds',stability<3,finished_temporal_mae=stability)
        roi=(slice(508,518),slice(180,600));outside=float(abs(frames[mode][first][roi].astype(float)-frames['control'][first][roi].astype(float)).mean());add(mode+'-outside-selection-unchanged',outside<3,mae=outside)
        for t in [.5,6,duration-1]:
            n=round(t*30);a1=frames[mode][n];bg=frames['control'][n];hole=(slice(366,375),slice(1026,1035));hole_mae=float(abs(a1[hole].astype(float)-bg[hole].astype(float)).mean());magenta=int(((a1[hole][:,:,0]>200)&(a1[hole][:,:,2]>180)&(a1[hole][:,:,1]<70)).sum());add(mode+f'-mask-alpha-hole-{n}',hole_mae<6 and magenta==0,background_mae=hole_mae,magenta_pixels=magenta)
        samples=[frames[mode][first][255:265,915:925].mean(axis=(0,1)),frames[mode][first][255:265,1135:1145].mean(axis=(0,1))];errors=[float(abs(sample-np.array(expected)).mean()) for sample,expected in zip(samples,[[80,206,154],[152,102,217]])];add(mode+'-mask-colour-and-direction',max(errors)<10,observed_rgb=[v.tolist() for v in samples],source_colour_mae=errors)
        area=frames[mode][first][220:520,880:1180];red=int(((area[:,:,0]>200)&(area[:,:,1]<90)&(area[:,:,2]<90)).sum());add(mode+'-source-crop-excludes-red-border',red==0,red_pixels=red)
        outside=(slice(225,515),slice(860,875));diff=float(abs(frames[mode][first][outside].astype(float)-frames['control'][first][outside].astype(float)).mean());add(mode+'-mask-output-bounds',diff<3,outside_slot_mae=diff)
        saved=read(out/(mode+'-save.json'))['response'];compiled=read(out/(mode+'-compile.json'))['response']['timeline_plan'];authored=read(out/(mode+'-authored.json'));mask=saved['request']['masks'][0];same_mask=all(mask[k]==v for k,v in authored['masks'][0].items());folder=out/'data'/idx['project_id']/'timeline-plans'/saved['id'];hash_ok=all(hashlib.sha256((folder/v['relative_path']).read_bytes()).hexdigest()==v['sha256'] for v in saved['sources']);binding=next(v for v in saved['sources'] if v['id']=='window');raw_hash=hashlib.sha256((ROOT/'materials'/'original_alpha_window.png').read_bytes()).hexdigest();add(mode+'-compiled-mask-frozen-binding',same_mask and saved['request']==compiled and hash_ok and binding['sha256']==raw_hash,compile_save_exact=saved['request']==compiled,mask_fields_preserved=same_mask,all_frozen_sources_match=hash_ok,original_alpha_png_sha256=raw_hash)
    seal=read(ROOT/'SEALED-SUPPLEMENT-MANIFEST.json');unchanged=all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==v for n,v in seal['files'].items());add('all-pre-read-sealed-files-unchanged',unchanged)
    negative=read(out/'negative-summary.json');add('negative-rejections-and-invariants',negative['all_pass'],details=negative)
    sheet=Image.new('RGB',(1280,390*len(times)),'#dce6e9')
    for row,t in enumerate(times):
        for col,mode in enumerate(['multiply','invert']):
            im=Image.fromarray(frames[mode][round(t*30)]);im.thumbnail((640,360));sheet.paste(im,(col*640,row*390));ImageDraw.Draw(sheet).text((col*640+10,row*390+367),f'ACTUAL {mode} {t:.1f}s',fill='#203e4e')
    sheet.save(ev/'actual-scans-and-alpha-window.jpg',quality=95);result={'status':'PASS' if all(v['pass'] for v in checks) else 'FAIL','checks':checks,'scope':'Separate Windows native diagnostic supplement only; no aesthetic/human listening/ASR/main-showcase/Mac/master_audio acceptance'};write(ev/'RESULT.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
